#include "globalPinDefinitions.h"
#include <Arduino.h>

void disableCANBus();
