#include <Arduino.h>
#include "globalPinDefinitions.h"

void initiateSolenoid();
void openSolenoid();
void closeSolenoid();
