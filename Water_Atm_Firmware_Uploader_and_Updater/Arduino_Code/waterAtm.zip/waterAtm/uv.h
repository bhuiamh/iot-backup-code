#include <Arduino.h>
#include "globalPinDefinitions.h"

void initiateUv();
void openUv();
void closeUv();
